"""UniSchedule desktop application package."""
